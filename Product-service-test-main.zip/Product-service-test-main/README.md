# Product-service-test
# Test logiciel java

Voici un service de gestion de produits. A vous de faire les tests unitaires pour valider les règles métiers. A vous de faire les tests d'intégrations pour valider le fonctionnement avec la BDD.

Quelques méthodes de tests ont leur définition d'écrite mais pas le corps, à vous de les remplir et d'ajouter les méthodes manquantes.

100% des règles métiers doivent être testées. 100% des processus doivent être validés.

Faites un Fork du projet et pensez à effectuer vos commits régulièrement. Seul le dernier commit avant l'heure de fin de l'examen sera pris en compte.

Bon courage.
